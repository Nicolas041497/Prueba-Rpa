﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        
        List<string> cadenas = new List<string>
        {
            "Hola",
            "Automatización",
            "RPA2026",
            "Desarrollo",
            "Test"
        };

        Console.WriteLine("Validacion de cadenas\n");

        foreach (var cadena in cadenas)
        {
            Console.WriteLine($"Cadena: {cadena}");

            bool soloAlfabeticos = ContieneSoloLetras(cadena);
            Console.WriteLine($"- Solo contiene letras: {soloAlfabeticos}");

            bool longitudValida = ValidarLongitud(cadena, 5, 10);
            Console.WriteLine($"- Longitud entre 5 y 10: {longitudValida}");

            int contadorChar = ContarCaracter(cadena, 'a');
            Console.WriteLine($"- Veces que aparece 'a': {contadorChar}");

            Console.WriteLine(">>>>>>>>>>>>>><<<<<<<<<<<<<\n");
        }

        Console.WriteLine("Fin validación de la lista.");
    }
    
    static bool ContieneSoloLetras(string cadena)
    {
        return cadena.All(char.IsLetter);
    }

    static bool ValidarLongitud(string cadena, int min, int max)
    {
        return cadena.Length >= min && cadena.Length <= max;
    }    
    static int ContarCaracter(string cadena, char caracter)
    {
        return cadena.Count(c => char.ToLower(c) == char.ToLower(caracter));
    }
}
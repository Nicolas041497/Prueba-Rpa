import pandas as pd
import json

# <<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<
#  Lee un archivo CSV y devuelve un DataFrame.
def leer_csv(ruta_csv: str):
    
    try:
        df = pd.read_csv(ruta_csv) 
        return df
    except Exception as e:
        print(f"Error al leer el archivo CSV: {e}")
        return None


# <<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<
# Calcula el total de las estadísticas básicas: Total Filas, Promedio de las columnas.
def calcular_estadisticas(df):
    
    if df is None:
        return None
    
    total_registros = len(df)

    # Filtra solo columnas numéricas y calcula su promedio
    promedios = df.select_dtypes(include=['number']).mean().to_dict()

    return {
        "total_registros": total_registros,
        "promedios_columnas": promedios
    }

# >>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#Filtra los registros donde la columna numérica sea mayor al umbral.
def filtrar_datos(df, columna="Salary", umbral=60000):
    
    if df is None:
        return None

    if columna not in df.columns:
        print(f"La columna '{columna}' no existe en el CSV.")
        return None

    filtrados = df[df[columna] > umbral]  # Filtrar filas
    return filtrados.to_dict(orient='records')  # Convertir a lista de diccionarios


# >>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# Guarda los resultados en un archivo JSON.
def guardar_json(nombre_archivo, estadisticas, filtrados):
    
    try:
        contenido = {
            "estadisticas": estadisticas,
            "registros_filtrados": filtrados
        }

        with open(nombre_archivo, "w") as f:
            json.dump(contenido, f, indent=4)

        print(f"Archivo JSON guardado como: {nombre_archivo}")

    except Exception as e:
        print(f"Error al guardar el archivo JSON: {e}")

#>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

if __name__ == "__main__":
    ruta_csv = "Datos.csv" 

    df = leer_csv(ruta_csv)  

    if df is not None:
        estadisticas = calcular_estadisticas(df)        
        filtrados = filtrar_datos(df, columna="Salary", umbral=60000)  

        guardar_json("resultado.json", estadisticas, filtrados)  

        print("Proceso completado con éxito.")
        print("Archivo JSON generado: resultado.json")
    else:
        print("No se pudo procesar el CSV.")